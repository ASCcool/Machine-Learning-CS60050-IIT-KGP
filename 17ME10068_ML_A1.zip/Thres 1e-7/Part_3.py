# Part 3.a

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('Error_Values.csv')
train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')

# n values for max. and min. train errors respectively 
n_max = 1+df['Train_Error'].idxmax()
n_min = 1+df['Train_Error'].idxmin()

# Data Creation

L = [];
M = []
X = train['Feature']
X = list(X)
Y = test['Feature']
Y = list(Y)

for i in range(0,10):
    L.append([x**i for x in X])
    M.append([y**i for y in Y])
    
X_train = np.array(L).T
X_test = np.array(M).T

m = train.shape[0]
m_test = test.shape[0]
y = np.array(train[' Label']).reshape(-1,1)
y_test = np.array(test[' Label']).reshape(-1,1)
alpha = 0.05
threshold = 0.0000001

Theta_max = []
Train_Error_max = []
Test_Error_max = []
Pred_max = []

Theta_min = []
Train_Error_min = []
Test_Error_min = []
Pred_min = []

for z in [n_max+1,n_min+1]:
    X = X_train[:,:z]
    T = X_test[:,:z]
    Lambda = [0.25,0.5,0.75,1]
    for lambd in Lambda:
        theta = np.zeros((z,1))
        
        i = 0
        val = 10000000
        j_new = 10000

        X = X_train[:,:z]
        T = X_test[:,:z]
        
        while(abs(val)>=threshold):

            j = (np.sum((np.dot(X,theta)-y)**2) + lambd*sum((theta[1:])))/(2*m)
            theta[0] = theta[0] - (alpha*(1/m)*(np.dot(X.T,(np.dot(X,theta)-y)))[0])
            theta[1:] = theta[1:] - (alpha*(1/m)*(np.dot(X.T,(np.dot(X,theta)-y)) + 0.5*lambd)[1:])
            j_new = (sum((np.dot(X,theta)-y)**2) + lambd*sum((theta[1:])))/(2*m)
            # either if j value becomes saturated or it increases, we stop 
            if(j_new==j or j_new>j):
                break
            val = abs(j_new-j)
            #print(i)
            i = i + 1

        print(j_new)   
        print('Polynomial '+str(z-1)+' lambda '+str(lambd))
        y_pred = np.dot(T,theta)
        test_error = (np.sum((np.dot(T,theta)-y_test)**2) + lambd*sum((theta[1:])))/(2*m_test)
        train_error = (np.sum((np.dot(X,theta)-y)**2) + lambd*sum((theta[1:])))/(2*m)
        
        if z == n_max+1:
            Pred_max.append(y_pred)
            Theta_max.append(theta)
            Test_Error_max.append(test_error.reshape(1,)[0])
            Train_Error_max.append(train_error.reshape(1,)[0])
        elif z == n_min+1:
            Pred_min.append(y_pred)
            Theta_min.append(theta)
            Test_Error_min.append(test_error.reshape(1,)[0])
            Train_Error_min.append(train_error.reshape(1,)[0])



x = Lambda
plt.figure()
plt.title('Lasso regression for Polynomial of degree '+str(n_max))
plt.xlabel('Lambda')
plt.ylabel('Error Values')
plt.plot(x,Train_Error_max,'ro-', label='Training Set')
plt.plot(x,Test_Error_max,'go-', label='Test Set')
plt.legend()
plt.savefig('Lasso regression for Polynomial of degree '+str(n_max)+'.jpg')


plt.figure()
plt.title('Lasso regression for Polynomial of degree '+str(n_min))
plt.xlabel('Lambda')
plt.ylabel('Error Values')
plt.plot(x,Train_Error_min,'ro-', label='Training Set')
plt.plot(x,Test_Error_min,'go-', label='Test Set')
plt.legend()
plt.savefig('Lasso regression for Polynomial of degree '+str(n_min)+'.jpg')


# Part 3.b

# Data Creation

L = [];
M = []
X = train['Feature']
X = list(X)
Y = test['Feature']
Y = list(Y)

for i in range(0,10):
    L.append([x**i for x in X])
    M.append([y**i for y in Y])
    
X_train = np.array(L).T
X_test = np.array(M).T

m = train.shape[0]
m_test = test.shape[0]
y = np.array(train[' Label']).reshape(-1,1)
y_test = np.array(test[' Label']).reshape(-1,1)
alpha = 0.05
threshold = 0.0000001

b_Theta_max = []
b_Train_Error_max = []
b_Test_Error_max = []
b_Pred_max = []

b_Theta_min = []
b_Train_Error_min = []
b_Test_Error_min = []
b_Pred_min = []

for z in [n_max+1,n_min+1]:
    X = X_train[:,:z]
    T = X_test[:,:z]
    Lambda = [0.25,0.5,0.75,1]
    for lambd in Lambda:
        theta = np.zeros((z,1))
        
        i = 0
        val = 10000000
        j_new = 10000

        X = X_train[:,:z]
        T = X_test[:,:z]
        while(abs(val)>=threshold):

            j = (np.sum((np.dot(X,theta)-y)**2) + lambd*np.sum((theta[1:]**2)))/(2*m)
            theta[0] = theta[0] - (alpha*(1/m)*(np.dot(X.T,(np.dot(X,theta)-y)))[0])
            theta[1:] = theta[1:]*(1-alpha/m) - (alpha*(1/m)*np.dot(X.T,(np.dot(X,theta)-y))[1:])
            j_new = (np.sum((np.dot(X,theta)-y)**2) + lambd*np.sum((theta[1:]**2)))/(2*m)
            if(j_new==j or j_new>j):
                break
            val = abs(j_new-j)
            i = i + 1

        print(j_new)    
        print('Polynomial '+str(z-1)+' lambda '+str(lambd))
        y_pred = np.dot(T,theta)
        test_error = (np.sum((np.dot(T,theta)-y_test)**2) + lambd*np.sum((theta[1:]**2)))/(2*m_test)
        train_error = (np.sum((np.dot(X,theta)-y)**2) + lambd*np.sum((theta[1:]**2)))/(2*m)

        if z == n_max+1:
            b_Pred_max.append(y_pred)
            b_Theta_max.append(theta)
            b_Test_Error_max.append(test_error.reshape(1,)[0])
            b_Train_Error_max.append(train_error.reshape(1,)[0])
        elif z == n_min+1:
            b_Pred_min.append(y_pred)
            b_Theta_min.append(theta)
            b_Test_Error_min.append(test_error.reshape(1,)[0])
            b_Train_Error_min.append(train_error.reshape(1,)[0])

x = Lambda
plt.figure()
plt.title('Ridge regression for Polynomial of degree '+str(n_max))
plt.xlabel('Lambda')
plt.ylabel('Error Values')
plt.plot(x,b_Train_Error_max,'ro-', label='Training Set')
plt.plot(x,b_Test_Error_max,'go-', label='Test Set')
plt.legend()
plt.savefig('Ridge regression for Polynomial of degree '+str(n_max)+'.jpg')


plt.figure()
plt.title('Ridge regression for Polynomial of degree '+str(n_min))
plt.xlabel('Lambda')
plt.ylabel('Error Values')
plt.plot(x,b_Train_Error_min,'ro-', label='Training Set')
plt.plot(x,b_Test_Error_min,'go-', label='Test Set')
plt.legend()
plt.savefig('Ridge regression for Polynomial of degree '+str(n_min)+'.jpg')
