# Part 1.a

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')

plt.figure()
plt.title('Training Data')
plt.xlabel('Train Feature')
plt.ylabel('Train Label')
plt.plot(train['Feature'],train[' Label'],'r.')
plt.savefig('train_feature_vs_label.jpg')

plt.figure()
plt.title('Test Data')
plt.xlabel('Test Feature')
plt.ylabel('Test Label')
plt.plot(test['Feature'],test[' Label'],'g.')
plt.savefig('test_feature_vs_label.jpg')

# Part 1.b

# Data Creation

L = [];
M = []
X = train['Feature']
X = list(X)
Y = test['Feature']
Y = list(Y)

for i in range(0,10):
    L.append([x**i for x in X])
    M.append([y**i for y in Y])

X_train = np.array(L).T
X_test = np.array(M).T

m = train.shape[0]
m_test = test.shape[0]
y = np.array(train[' Label']).reshape(-1,1)
y_test = np.array(test[' Label']).reshape(-1,1)
alpha = 0.05
threshold = 0.0000001

Theta = []
Train_Error = []
Test_Error = []
Pred = []


for z in range(2,11):
    theta = np.zeros((z,1))
    i = 0
    val = 10000000
    j_new = 10000
    
    X = X_train[:,:z]
    T = X_test[:,:z]
    while(abs(val)>=threshold):
        
        j = np.sum((np.dot(X,theta)-y)**2)/(2*m)
        theta = theta - alpha*(1/m)*np.dot(X.T,(np.dot(X,theta)-y))
        j_new = sum((np.dot(X,theta)-y)**2)/(2*m)
        if(j_new==j or j_new>j):
            break
        val = abs(j_new-j)
        i = i + 1
    
    print(j_new)
    print('Polynomial '+str(z-1))
    y_pred = np.dot(T,theta)
    Pred.append(y_pred)
    Theta.append(theta)
    test_error = sum((np.dot(T,theta)-y_test)**2)/(2*m_test)
    Test_Error.append(test_error.reshape(1,)[0])
    train_error = sum((np.dot(X,theta)-y)**2)/(2*m)
    Train_Error.append(train_error.reshape(1,)[0])

# Write Theta Values
d = {'Theta '+str(i+1):list(Theta[i].reshape(Theta[i].shape[0])) for i in range(9)}
df = pd.DataFrame({key: pd.Series(value) for key, value in d.items()})
df.to_csv('Theta_Values.csv', index=False)


# Write Test_Lables
pd.DataFrame({'Test_Label '+str(i+1):list(Pred[i].reshape(200,)) for i in range(9)}).to_csv('Test_Labels.csv')


# Write Error Values
pd.DataFrame({'Train_Error':Train_Error,'Test_Error':Test_Error}).to_csv('Error_Values.csv')

