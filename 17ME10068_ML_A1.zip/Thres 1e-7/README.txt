*************************************************README.txt file for Assignment 1*****************************************************
Sequence of execution of codes :

Part_1.py==>Part_2.py==>Part_3.py

Part_1.py saves two images : train_feature_vs_label.jpg and test_feature_vs_label.jpg {Part 1.a} followed by files Theta_Values.csv, Test_Labels.csv and Error_Values.csv {Part 1.b}

Part_2.py saves 9 images of learnt polynomial curves of degree 1 to 9 on training set (train1.jpg to train9.jpg) and 9 similar images
on test set (test1.jpg to test9.jpg) {Part 2.a} followed by an image Error_Values for Gradient Descent.jpg {Part 2.b}

Part_3.py saves images Lasso regression for Polynomial of degree 1.jpg, Lasso regression for Polynomial of degree 4.jpg {Part 3.a} followed by the images Ridge regression for Polynomial of degree 1.jpg, Ridge regression for Polynomial of degree 4.jpg {Part 3.b}

