# Part 2.a

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

train = pd.read_csv('train.csv')
test = pd.read_csv('test.csv')

L = [];
R = [];

X = train['Feature']
X = list(X)
Y = test['Feature']
Y = list(Y)
for i in range(0,10):
    L.append([x**i for x in X])
    R.append([y**i for y in Y])
    
X_train = np.array(L).T
X_test = np.array(R).T

# Read Theta Values
df = pd.read_csv('Theta_Values.csv')
theta = []
for i in range(9):
    theta.append(np.array(df['Theta '+str(i+1)].iloc[0:i+2]).reshape(-1,1))

for z in range(2,11):
    
    X = X_train[:,:z]
    h = np.dot(X,theta[z-2])
    x = X_train[:,1]
    # Training set
    plt.figure()
    plt.title('Degree of Polynomial = '+str(z-1))
    plt.xlabel('x')    
    plt.ylabel('y')
    plt.plot(train['Feature'],train[' Label'],'r.',label='Actual Training Set')
    plt.plot(x,h,'b.',label='Predictions on Training Set')
    plt.legend()
    plt.savefig('train'+str(z-1)+'.jpg')
    
    X = X_test[:,:z]
    h = np.dot(X,theta[z-2])
    x = X_test[:,1]
    # Test set
    plt.figure()
    plt.title('Degree of Polynomial = '+str(z-1))
    plt.xlabel('x')    
    plt.ylabel('y')
    plt.plot(test['Feature'],test[' Label'],'y.',label='Actual Test Set')
    plt.plot(x,h,'g.',label='Predictions on Test Set')
    plt.legend()
    plt.savefig('test'+str(z-1)+'.jpg')


# Part 2.b

# Read Error Values

sf = pd.read_csv('Error_Values.csv')

x = list(np.arange(1,10))
plt.figure()
plt.xlabel('Degree of Polynomial')
plt.ylabel('Error Values')
plt.plot(x,sf['Train_Error'],'ro-', label='Training Set')
plt.plot(x,sf['Test_Error'],'go-', label='Test Set')
plt.legend()
plt.savefig('Error_Values for Gradient Descent.jpg')


print('Best value of n = '+str(1+sf['Test_Error'].idxmin()))
