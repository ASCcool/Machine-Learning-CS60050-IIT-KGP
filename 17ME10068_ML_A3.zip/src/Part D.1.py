
import numpy as np
import pandas as pd
from sklearn.decomposition import PCA


# In[ ]:


df = pd.read_csv('../data/norm.csv').drop(columns=['Unnamed: 0'])


# In[ ]:


X = df[df.columns[1:]].values
l = ['PC '+str(i) for i in range(1,101)]
pca = PCA(n_components=100)
pc = pca.fit_transform(X)


# In[ ]:


pd.DataFrame(pc,columns=l).to_csv('../data/PCA_Processed.csv')

