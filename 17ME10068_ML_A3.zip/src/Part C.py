
import numpy as np
import pandas as pd
import copy


# In[ ]:


df = pd.read_csv('../data/norm.csv').drop(columns = ['Unnamed: 0'])


# In[ ]:


X = df[df.columns[1:]].values


# In[ ]:


def cosine_distance(v1,v2):
    return np.exp(-(v1.T@v2))
def calc_distance(X):
    distance_matrix = np.zeros((X.shape[0],X.shape[0]))
    for i in range(X.shape[0]):
        for j in range(i):
            distance_matrix[i][j] = cosine_distance(X[i],X[j])
            distance_matrix[j][i] = distance_matrix[i][j]
    return distance_matrix


# In[ ]:


m=X.shape[0] # number of training examples
n=X.shape[1] # number of features
K=8 # number of clusters


# In[ ]:


# Random Centroids Initilalization

centroid_dict = {}
error = []
for j in range(300):
    Centroids=np.zeros((K,n))
    for i in range(K):
        rand=np.random.randint(0,m-1)
        Centroids[i]=X[rand]
    Centroids=Centroids.T
    centroid_dict[str(j)]=Centroids
    s = 0
    for y in range(m):
        d = cosine_distance(X[y],Centroids)
        s += d.min()**2
    error.append(s)


# In[ ]:


Centroids = centroid_dict[str(np.array(error).argmin())]


# In[ ]:


Output={}
Output_old={}
for i in range(K):
    Output[str(i)]= []  


# In[ ]:


iters = 0
while Output_old != Output:
    iters += 1
    print(iters)
    Output_old = copy.deepcopy(Output)
    for i in range(K):
        Output[str(i)]= []  
    for i in range(m):
        d = cosine_distance(X[i],Centroids)
        Output[str(d.argmin())].append(i)
    print(Output_old == Output)
    if Output_old == Output:
        break
    for k in range(K):
        np.array(df[df.columns[1:]].iloc[Output[str(k)]].mean(axis=0))
        Centroids[:,k]=np.array(df[df.columns[1:]].iloc[Output[str(k)]].mean(axis=0))


# In[ ]:


l1 = [0,1,2,3,4,5,6,7]
l2 = []
for key,value in Output.items():
    value.sort()
    l2.append(value[0])


# In[ ]:


def sort_list(list1, list2): 
    zipped_pairs = zip(list2, list1) 
    z = [x for _, x in sorted(zipped_pairs)]  
    return z 


# In[ ]:


f = open('../clusters/kmeans.txt', 'w')
l3 = sort_list(l1,l2)
for i in range(len(l3)):
    value = Output[str(l3[i])]
    s = ",".join(map(str,value))
    f.write(s +"\n")
f.close()

