
import numpy as np
import pandas as pd
import sys


# In[ ]:


MAX = sys.maxsize


# In[ ]:


sf = pd.read_csv('../data/PCA_Processed.csv').drop(columns='Unnamed: 0')


# In[ ]:


data = sf.values


# In[ ]:


def inv_cosine_distance(v1,v2):
    return np.exp(-(v1.T@v2))
def calc_distance(X):
    distance_matrix = np.zeros((X.shape[0],X.shape[0]))
    for i in range(X.shape[0]):
        for j in range(i):
            distance_matrix[i][j] = inv_cosine_distance(X[i],X[j])
            distance_matrix[j][i] = distance_matrix[i][j]
    return distance_matrix


# In[ ]:


def agg_hierarchical_clustering(data,num_clusters):  
    d_0 = calc_distance(data)
    np.fill_diagonal(d_0,MAX)
    clusters = clusters_finder(d_0) 
    iter_num = d_0.shape[0] - num_clusters
    clusters_final = clusters[iter_num]
    arr = np.unique(clusters_final)
    return clusters_final


# In[ ]:


def clusters_finder(init_val):
    clusters = {}
    r_idx = -1
    c_idx = -1
    array = []
    for n in range(init_val.shape[0]):
        array.append(n)   
    clusters[0] = array.copy()
    for k in range(1, init_val.shape[0]):
        min_val = sys.maxsize
        for i in range(0, init_val.shape[0]):
            for j in range(0, init_val.shape[1]):
                if(init_val[i][j]<=min_val):
                    min_val = init_val[i][j]
                    r_idx = i
                    c_idx = j
        for i in range(0,init_val.shape[0]):
            if(i != c_idx):
                temp = min(init_val[c_idx][i],init_val[r_idx][i])
                init_val[c_idx][i] = temp
                init_val[i][c_idx] = temp    
        for i in range (0,init_val.shape[0]):
            init_val[r_idx][i] = sys.maxsize
            init_val[i][r_idx] = sys.maxsize
        minimum = min(r_idx,c_idx)
        maximum = max(r_idx,c_idx)
        for n in range(len(array)):
            if(array[n]==maximum):
                array[n] = minimum
        clusters[k] = array.copy()
    return clusters


# In[ ]:

clusters = agg_hierarchical_clustering(data,8)


# In[ ]:


cluster_labels = pd.Series(clusters).unique()


# In[ ]:


D1 = {}
for k in range(cluster_labels.shape[0]):
    indices = [i for i, x in enumerate(clusters) if x == cluster_labels[k]]
    D1["Cluster "+str(k+1)] = indices


# In[ ]:


D1


# In[ ]:


l1 = [0,1,2,3,4,5,6,7]
l2 = []
for key,value in D1.items():
    value.sort()
    l2.append(value[0])


# In[ ]:


def sort_list(list1, list2): 
    zipped_pairs = zip(list2, list1) 
    z = [x for _, x in sorted(zipped_pairs)]  
    return z 


# In[ ]:


f = open('../clusters/agglomerative_reduced.txt', 'w')
l3 = sort_list(l1,l2)
for i in range(len(l3)):
    value = D1["Cluster "+str(l3[i]+1)]
    s = ",".join(map(str,value))
    f.write(s +"\n")
f.close()

