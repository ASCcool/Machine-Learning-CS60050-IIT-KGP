
import numpy as np
import pandas as pd
from sklearn import *
from sklearn.preprocessing import Normalizer


# In[ ]:


df = pd.read_csv('../data/AllBooks_baseline_DTM_Labelled.csv')


# In[ ]:


df.loc[df['Unnamed: 0'].str.contains('Buddhism'),'Unnamed: 0'] = 'Buddhism'
df.loc[df['Unnamed: 0'].str.contains('TaoTeChing'),'Unnamed: 0'] = 'TaoTeChing'
df.loc[df['Unnamed: 0'].str.contains('Upanishad'),'Unnamed: 0'] = 'Upanishad'
df.loc[df['Unnamed: 0'].str.contains('YogaSutra'),'Unnamed: 0'] = 'YogaSutra'
df.loc[df['Unnamed: 0'].str.contains('BookOfProverb'),'Unnamed: 0'] = 'BookOfProverb'
df.loc[df['Unnamed: 0'].str.contains('BookOfEcclesiastes'),'Unnamed: 0'] = 'BookOfEcclesiastes'
df.loc[df['Unnamed: 0'].str.contains('BookOfEccleasiasticus'),'Unnamed: 0'] = 'BookOfEccleasiasticus'
df.loc[df['Unnamed: 0'].str.contains('BookOfWisdom'),'Unnamed: 0'] = 'BookOfWisdom'


# In[ ]:


df.drop([13],axis = 0,inplace = True)


# In[ ]:


df.reset_index(inplace =True,drop=True)


# In[ ]:


df.rename(columns={"Unnamed: 0": "Label"},inplace = True)


# In[ ]:


df.to_csv('../data/Processed_Original.csv') # Removed 13th row (with all zeros)


# In[ ]:


n = df.shape[0]
DF = []
IDF = []
i = 0
for col in df.columns[1:]:
    DF.append(df[df[col]!=0].shape[0])
    IDF.append(np.log((1+n)/DF[i]))
    i += 1


# In[ ]:


i = 0
for col in df.columns[1:]:
    df[col] *= IDF[i]
    i += 1


# In[ ]:


X = df[df.columns[1:]].values
transformer = Normalizer().fit(X)
w = transformer.transform(X)


# In[ ]:


df[df.columns[1:]] = w


# In[ ]:


df.to_csv('../data/norm.csv') # use sklearn to handle norm for nan values

