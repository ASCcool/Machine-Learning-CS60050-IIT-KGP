
import numpy as np
import pandas as pd


# In[ ]:


df = pd.read_csv('../data/norm.csv')


# In[ ]:


def h_y(df):
    l = df['Label'].unique()
    n_tot = df.shape[0]
    s = 0
    for i in range(len(l)):
        n = df[df['Label']==l[i]].shape[0]
        s += -(n/n_tot)*np.log2(n/n_tot)
    return s


# In[ ]:


def h_c(d,df):
    n_tot = df.shape[0]
    s = 0
    p_list = []
    for i in range(len(d)):
        n = len(d[str(i)])
        p_list.append(n/n_tot)
        s += -(n/n_tot)*np.log2(n/n_tot)
    return s,p_list


# In[ ]:


def i_y_c(a,df):
    l = df['Label'].unique()
    Class = []
    for i in range(len(l)):
        s = 0
        for j in range(len(l)):
            n = np.count_nonzero(np.array(df.loc[d[str(i)]]['Label']==l[j]))
            if (n/len(d[str(i)]))==0:
                s += 0
            else:
                s += -(n/len(d[str(i)]))*np.log2(n/len(d[str(i)]))
        Class.append(a[i]*s)
    return sum(Class)


# In[ ]:


def nmi(df,d):
    return (2*(h_y(df)-i_y_c(h_c(d,df)[1],df))/(h_c(d,df)[0]+h_y(df)))


# In[ ]:


import ast
Files = ['agglomerative.txt','kmeans.txt','agglomerative_reduced.txt','kmeans_reduced.txt']
NMI = []
for file in Files:
    lines = open('../clusters/'+file).read().splitlines()
    d = {}
    for z in range(8):
        d[str(z)]=[]
    i = 0
    for i in range(8):
        if type(ast.literal_eval(lines[i]))==tuple:
            d[str(i)] = list(ast.literal_eval(lines[i]))
        elif type(ast.literal_eval(lines[i]))==int:
            d[str(i)] = [ast.literal_eval(lines[i])]
    NMI.append(nmi(df,d))


# In[ ]:


print(NMI)

