#!/usr/bin/env python
# coding: utf-8

# In[3]:


#With sklearn

import numpy as np
import pandas as pd
from sklearn import model_selection
from sklearn import metrics
from sklearn.linear_model import LogisticRegression

df = pd.read_csv('../data/Dataset A.csv')
df.drop(['Unnamed: 0'],axis = 1,inplace = True)
kfold = model_selection.KFold(n_splits=3)
model = LogisticRegression(solver = 'saga', penalty = 'none')
y = np.array(df)[:,-1].reshape(-1,1)
X = np.array(df)[:,:11]
model.fit(X,y)
results = model_selection.cross_val_score(model, X, y, cv=kfold)
accuracy = model_selection.cross_val_score(model, X, y, cv=kfold, scoring='accuracy')
precision = model_selection.cross_val_score(model, X, y, scoring='precision', cv=kfold)
recall = model_selection.cross_val_score(model, X, y, scoring='recall', cv=kfold)
print("Accuracy: " + str(accuracy.mean()*100) + str("%"))
print("Precision score: " + str(precision.mean()))
print("Recall score: " + str(recall.mean()))

