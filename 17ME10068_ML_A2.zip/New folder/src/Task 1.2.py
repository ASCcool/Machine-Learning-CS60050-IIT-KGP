#!/usr/bin/env python
# coding: utf-8

# In[3]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd

# Part B

df = pd.read_csv('../data/winequality-red.csv',sep=';')

df.loc[df['quality'] < 5, 'quality'] = 0
df.loc[df['quality'] == 5, 'quality'] = 1
df.loc[df['quality'] == 6, 'quality'] = 1
df.loc[df['quality'] > 6, 'quality'] = 2

cols = list(df.columns)
cols.remove('quality')

df2 = pd.DataFrame()
for col in cols:
    df2[col] = (df[col] - df[col].mean())/df[col].std(ddof=0)
df2['quality']=df['quality']

for col in cols:
    df2[col] = pd.qcut(df2[col], q=4, labels = ['0','1','2','3'])

df2.to_csv('../data/Dataset B.csv')

