#!/usr/bin/env python
# coding: utf-8

# In[19]:


import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


# In[21]:


# Part A

df = pd.read_csv('../data/winequality-red.csv',sep=';')

df.loc[df['quality'] <= 6, 'quality'] = 0
df.loc[df['quality'] > 6, 'quality'] = 1

df1=((df-df.min())/(df.max()-df.min()))
df1['quality']=df['quality']

df1.to_csv('../data/Dataset A.csv')

