#!/usr/bin/env python
# coding: utf-8

# In[8]:


import numpy as np
import pandas as pd
from numpy import log2 as log


# In[9]:


df = pd.read_csv('../data/Dataset B.csv')
df.drop(['Unnamed: 0'],axis = 1,inplace = True)


# In[10]:


def CV_data_generator(df,fold):
    m = np.int(df.shape[0]/3)
    df1 = df[:m]
    df2 = df[m:2*m]
    df3 = df[2*m:]
    
    if fold==1:
        return df[m:].reset_index().drop(['index'],axis = 1),df1.reset_index().drop(['index'],axis = 1)
    elif fold==2:
        return pd.concat([df1,df3],axis=0).reset_index().drop(['index'],axis = 1),df2.reset_index().drop(['index'],axis = 1)
    elif fold==3:
        return df[:2*m].reset_index().drop(['index'],axis = 1),df3.reset_index().drop(['index'],axis = 1)


def Entropy_Calculator(df):
    clval = df.keys()[-1]
    Entropy = 0
    values = df[clval].unique()
    for val in values:
        Fraction = df[clval].value_counts()[val]/len(df[clval])
        Entropy += -Fraction*np.log2(Fraction)
    return Entropy
  
  
def Attribute(df,attribute):
    clval = df.keys()[-1]   
    target_variables = df[clval].unique()  
    variables = df[attribute].unique() 
    Entropy2 = 0
    eps = np.finfo(float).eps
    for variable in variables:
        Entropy = 0
        for target_variable in target_variables:
            num = len(df[attribute][df[attribute]==variable][df[clval] ==target_variable])
            den = len(df[attribute][df[attribute]==variable])
            Fraction = num/(den+eps)
            Entropy += -Fraction*log(Fraction+eps)
        Fraction2 = den/len(df)
        Entropy2 += -Fraction2*Entropy
    return abs(Entropy2)


def Node_Split(df):
    Entropy_att = []
    Info_Gain = []
    for key in df.keys()[:-1]:
        Info_Gain.append(Entropy_Calculator(df)-Attribute(df,key))
    return df.keys()[:-1][np.argmax(Info_Gain)]
  
  
def Sub_Attribute_Finder(df, node,value):
    return df[df[node] == value].reset_index(drop=True)


def Tree_Builder(df,tree=None): 
    clval = df.keys()[-1]   
    node = Node_Split(df)
    attValue = np.unique(df[node])
       
    if tree is None:                    
        tree={}
        tree[node] = {}

    for value in attValue:
        
        reduced_data = Sub_Attribute_Finder(df,node,value)
        # Class values and the no. of samples corresponding to the classes 
        clValue,counts = np.unique(reduced_data['quality'],return_counts=True)                        
        if len(counts)==0:
            tree[node][value] = None
        if len(counts)==1:
            tree[node][value] = clValue[0]
            for z in range(attValue.max()+1):
                if z!=value:
                    tree[node][z]=None   
        # Min sample points to split = 10. If less than 10 samples, do not split
        elif sum(counts)<10: 
            tree[node][value] = np.array(clValue).argmax()
            for z in range(attValue.max()+1):
                if z!=value:
                    tree[node][z]=None
            return 
        else:        
            tree[node][value] = Tree_Builder(reduced_data) 
                   
    return tree

def predict(inst,tree):
    for nodes in tree.keys():        
        
        value = inst[nodes]
        tree = tree[nodes][value]
        prediction = 0
        
        if type(tree) is dict:
            prediction = predict(inst, tree)
        else:
            prediction = tree
            break;                            
        
    return prediction

from sklearn.metrics import *

def metrics(df,tree):
    ylabel = [];
    for i in range(len(df)):
        ylabel.append(predict(df.iloc[i],tree))
    for i in range(len(ylabel)):
        if ylabel[i]==None:
            ylabel[i]=1
    ygr = list(df['quality'])
    return precision_score(ygr,ylabel,average = 'macro'),recall_score(ygr,ylabel,average = 'macro'),accuracy_score(ygr,ylabel)


# In[11]:


Tree = []
Test_Metrics = {};
Test_Metrics['Precision'] = []
Test_Metrics['Recall'] = []
Test_Metrics['Accuracy'] = []
Train_Metrics = {};
Train_Metrics['Precision'] = []
Train_Metrics['Recall'] = []
Train_Metrics['Accuracy'] = []
for i in range(1,4):
    df_train,df_test = CV_data_generator(df,i)
    tree = Tree_Builder(df_train)
    Tree.append(tree)
    a,b,c = metrics(df_train,Tree[i-1])
    Train_Metrics['Precision'].append(a)
    Train_Metrics['Recall'].append(b)
    Train_Metrics['Accuracy'].append(c)
    a,b,c = metrics(df_test,Tree[i-1])
    Test_Metrics['Precision'].append(a)
    Test_Metrics['Recall'].append(b)
    Test_Metrics['Accuracy'].append(c)


# In[12]:


print("Train Accuracy: " + str(np.array(Train_Metrics['Accuracy']).mean()*100) + str("%"))
print("Train Precision score: " + str(np.array(Train_Metrics['Precision']).mean()))
print("Train Recall score: " + str(np.array(Train_Metrics['Recall']).mean()))


# In[13]:


print("Test Accuracy: " + str(np.array(Test_Metrics['Accuracy']).mean()*100) + str("%"))
print("Test Precision score: " + str(np.array(Test_Metrics['Precision']).mean()))
print("Test Recall score: " + str(np.array(Test_Metrics['Recall']).mean()))

