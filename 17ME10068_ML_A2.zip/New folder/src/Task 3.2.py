#!/usr/bin/env python
# coding: utf-8

# In[4]:


# Using sklearn
import numpy as np
import pandas as pd
from sklearn import model_selection
from sklearn import metrics
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import *

df = pd.read_csv('../data/Dataset B.csv')
df.drop(['Unnamed: 0'],axis = 1,inplace = True)

kfold = model_selection.KFold(n_splits=3)
model = DecisionTreeClassifier(min_samples_split=10)
y = np.array(df)[:,-1].reshape(-1,1)
X = np.array(df)[:,:11]

accuracy = model_selection.cross_val_score(model, X, y, cv=kfold)
precision = model_selection.cross_val_score(model, X, y, scoring='precision_macro', cv=kfold)
recall = model_selection.cross_val_score(model, X, y, scoring='recall_macro', cv=kfold)
print("Accuracy: " + str(accuracy.mean()*100) + str("%"))
print("Precision score: " + str(precision.mean()))
print("Recall score: " + str(recall.mean()))

