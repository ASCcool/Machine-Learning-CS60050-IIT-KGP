#!/usr/bin/env python
# coding: utf-8

# In[110]:


import numpy as np
import pandas as pd


# In[111]:


df = pd.read_csv('../data/Dataset A.csv')
df.drop(['Unnamed: 0'],axis = 1,inplace = True)


# In[112]:


# Without sklearn

y = np.array(df)[:,-1].reshape(-1,1)
X = np.array(df)[:,:11]
X = np.insert(X,0,1,axis=1)

m = X.shape[0]
n = X.shape[1]

def split(X,y,fold):
    m = np.int(X.shape[0]/3)
    x1 = X[:m]
    x2 = X[m:2*m]
    x3 = X[2*m:]
    y1 = y[:m].reshape(-1,1)
    y2 = y[m:2*m].reshape(-1,1)
    y3 = y[2*m:].reshape(-1,1)
    
    if fold==1:
        return X[m:],y[m:],x1,y1
    elif fold==2:
        return np.concatenate((x1,x3),axis = 0),np.concatenate((y1,y3),axis = 0),x2,y2
    elif fold==3:
        return X[:2*m],y[:2*m],x3,y3

def sigmoid(X,theta):
    return 1/(1+np.exp(-np.dot(X,theta)))


Train_record = {}
Test_record = {}
Train_record['precision']=[]
Test_record['precision']=[]
Train_record['recall']=[]
Test_record['recall']=[]
Train_record['accuracy']=[]
Test_record['accuracy']=[]


for k in range(1,4):
    theta = 0.5*np.zeros((12,1))
    val = 10000000
    j_new = 10000
    threshold = 1e-8
    alpha = 0.01
    X_train,y_train,X_test,y_test = split(X,y,k);
    m = X_train.shape[0]
    while(abs(val)>=threshold):
        h = sigmoid(X_train,theta)
        j = (-y_train *np.log(h) - (1 - y_train) * np.log(1 - h)).mean()
        theta = theta - alpha*(1/m)*np.dot(X_train.T,(h-y_train))
        h = sigmoid(X_train,theta)
        j_new = (-y_train * np.log(h) - (1 - y_train) * np.log(1 - h)).mean()
        if(j_new==j or j_new>j):
            break
        val = abs(j_new-j)
    y_pred = 1/(1+np.exp(-np.dot(X_test,theta)))>=0.5
    Test_record['precision'].append(precision_score(y_test,y_pred))
    Test_record['recall'].append(recall_score(y_test,y_pred))
    Test_record['accuracy'].append(accuracy_score(y_test,y_pred))
    
    y_pred = 1/(1+np.exp(-np.dot(X_train,theta)))>=0.5
    Train_record['precision'].append(precision_score(y_train,y_pred))
    Train_record['recall'].append(recall_score(y_train,y_pred))
    Train_record['accuracy'].append(accuracy_score(y_train,y_pred))

print("Train_Accuracy: " + str(np.array(Train_record['accuracy']).mean()*100) + str("%"))
print("Train_Precision score: " + str(np.array(Train_record['precision']).mean()))
print("Train_Recall score: " + str(np.array(Train_record['recall']).mean()))

print("Test_Accuracy: " + str(np.array(Test_record['accuracy']).mean()*100) + str("%"))
print("Test_Precision score: " + str(np.array(Test_record['precision']).mean()))
print("Test_Recall score: " + str(np.array(Test_record['recall']).mean()))

